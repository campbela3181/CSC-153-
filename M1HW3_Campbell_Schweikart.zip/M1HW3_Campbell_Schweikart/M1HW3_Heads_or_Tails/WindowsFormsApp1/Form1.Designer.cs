﻿namespace Heads_Tails
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Show_Heads = new System.Windows.Forms.Button();
            this.Show_Tails = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.coinHeadspictureBox = new System.Windows.Forms.PictureBox();
            this.coinTailspictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.coinHeadspictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coinTailspictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // Show_Heads
            // 
            this.Show_Heads.Location = new System.Drawing.Point(12, 203);
            this.Show_Heads.Name = "Show_Heads";
            this.Show_Heads.Size = new System.Drawing.Size(103, 53);
            this.Show_Heads.TabIndex = 0;
            this.Show_Heads.Text = "Show Heads";
            this.Show_Heads.UseVisualStyleBackColor = true;
            this.Show_Heads.Click += new System.EventHandler(this.Heads_Click);
            // 
            // Show_Tails
            // 
            this.Show_Tails.Location = new System.Drawing.Point(158, 207);
            this.Show_Tails.Name = "Show_Tails";
            this.Show_Tails.Size = new System.Drawing.Size(103, 49);
            this.Show_Tails.TabIndex = 1;
            this.Show_Tails.Text = "Show Tails";
            this.Show_Tails.UseVisualStyleBackColor = true;
            this.Show_Tails.Click += new System.EventHandler(this.Show_Tails_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(297, 203);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(103, 53);
            this.Exit.TabIndex = 2;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // coinHeadspictureBox
            // 
            this.coinHeadspictureBox.Image = ((System.Drawing.Image)(resources.GetObject("coinHeadspictureBox.Image")));
            this.coinHeadspictureBox.Location = new System.Drawing.Point(12, 12);
            this.coinHeadspictureBox.Name = "coinHeadspictureBox";
            this.coinHeadspictureBox.Size = new System.Drawing.Size(152, 138);
            this.coinHeadspictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coinHeadspictureBox.TabIndex = 3;
            this.coinHeadspictureBox.TabStop = false;
            this.coinHeadspictureBox.Visible = false;
            // 
            // coinTailspictureBox
            // 
            this.coinTailspictureBox.Image = ((System.Drawing.Image)(resources.GetObject("coinTailspictureBox.Image")));
            this.coinTailspictureBox.Location = new System.Drawing.Point(248, 12);
            this.coinTailspictureBox.Name = "coinTailspictureBox";
            this.coinTailspictureBox.Size = new System.Drawing.Size(152, 138);
            this.coinTailspictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coinTailspictureBox.TabIndex = 4;
            this.coinTailspictureBox.TabStop = false;
            this.coinTailspictureBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 320);
            this.Controls.Add(this.coinTailspictureBox);
            this.Controls.Add(this.coinHeadspictureBox);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Show_Tails);
            this.Controls.Add(this.Show_Heads);
            this.Name = "Form1";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.coinHeadspictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coinTailspictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Show_Heads;
        private System.Windows.Forms.Button Show_Tails;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.PictureBox coinHeadspictureBox;
        private System.Windows.Forms.PictureBox coinTailspictureBox;
    }
}

