﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 01/30/18
* CSC 153
* Alicia Campbell-Brown
* Brian Schweikart
* Heads or Tails
*/


/**
 * Coins not shown until button is clicked
 * Each button will show heads or tails
 */

namespace Heads_Tails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Heads_Click(object sender, EventArgs e)
        {
            // show heads only on button click
            coinHeadspictureBox.Visible = true;
            coinTailspictureBox.Visible = false;
        }

        private void Show_Tails_Click(object sender, EventArgs e)
        {
            // show Tails only on button click
            coinTailspictureBox.Visible = true;
            coinHeadspictureBox.Visible = false;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
